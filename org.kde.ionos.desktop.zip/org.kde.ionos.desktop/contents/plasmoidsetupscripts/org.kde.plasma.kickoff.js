applet.currentConfigGroup = ["General"]
applet.writeConfig("icon", "/usr/share/plasma/look-and-feel/org.kde.ionos.desktop/contents/icons/deck_icon.png")
applet.reloadConfig()
