applet.wallpaperPlugin = 'org.kde.image'
applet.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"]
applet.writeConfig("Image", "/usr/share/wallpapers/ion-wallpaper.png")
applet.reloadConfig()
